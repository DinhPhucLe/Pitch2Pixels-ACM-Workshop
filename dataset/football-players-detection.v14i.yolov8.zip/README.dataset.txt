# football-players-detection > 2025-03-27 5:42pm
https://universe.roboflow.com/roboflow-jvuqo/football-players-detection-3zvbc

Provided by a Roboflow user
License: CC BY 4.0

